from database import db
class LivroCategoria(db.Model):
    __tablename__ = 'livro_categoria'
    livro_id = db.Column(db.Integer, db.ForeignKey('livro.id'), primary_key=True)
    categoria_id = db.Column(db.Integer, db.ForeignKey('categoria.id'), primary_key=True)