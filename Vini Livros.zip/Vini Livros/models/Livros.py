from database import db
class Livro(db.Model):
 id= db.Column(db.Integer,primary_key=True)
 titulo = db.Column(db.String(50), nullable=False)
 isbn = db.Column(db.String(50),  nullable=False)
 data_publicacao = db.Column(db.Date, nullable=False)
 numero_paginas = db.Column(db.Integer,  nullable=False)
 autor_id = db.Column(db.Integer, db.ForeignKey('autor.id'), nullable=False)
 categoria_id = db.Column (db.Integer)
 
 autor= db.relationship("Autor",back_populates="livros")
 categorias= db.relationship("Categoria",secondary="livro_categoria",back_populates="livros")
 def to_dict(self):
    return {
        'id': self.id,
        'titulo': self.titulo,
        'isbn': self.isbn,
        'autor': self.autor.nome if self.autor else None,
        'categorias': [categoria.nome for categoria in self.categorias]
    }