from dao import LivroCategoriaDAO
#Funções: Pegar todos os livro_categoria, Pegar livro_categoria pelo id, criar um novo livro_categoria, upar/atualizar um livro_categoria, deletar um livro_categoria
class LivroCategoriaRepository:
    def __init__(self) -> None:
        self.livroCategoriaDao = LivroCategoriaDAO()

    def get_all_livro_categoria(self):
        return self.livroCategoriaDao.get_all_livro_categoria()

    def get_livro_categoria_by_livro_id(self, livro_id):
        return self.livroCategoriaDao.get_livro_categoria_by_livro_id(livro_id)

    def get_livro_categoria_by_categoria_id(self, categoria_id):
        return self.livroCategoriaDao.get_livro_categoria_by_categoria_id(categoria_id)

    def add_livro_categoria(self, livro_id, categoria_id):
        return self.livroCategoriaDao.add_livro_categoria(livro_id, categoria_id)

    def remove_livro_categoria(self, livro_id, categoria_id):
        return self.livroCategoriaDao.remove_livro_categoria(livro_id, categoria_id)
    
    def livro_categoria_to_json(self, livro_categoria):
        return LivroCategoriaDAO.livro_categoria_to_json(livro_categoria)

    def livro_categorias_to_json(self, livros_categorias):
        return LivroCategoriaDAO.livro_categorias_to_json(livros_categorias)