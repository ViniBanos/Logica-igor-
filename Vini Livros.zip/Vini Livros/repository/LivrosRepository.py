from dao import LivroDAO
#Funções: Pegar todos os livros, Pegar livro pelo id, criar um novo livro, upar/atualizar um livro, deletar um livro
class LivroRepository:
    def __init__(self) -> None:
        self.livroDao = LivroDAO()

    def get_all_livros(self):
        return self.livroDao.get_all_Livros()

    def get_livro_by_id(self, livro_id):
        return self.livroDao.get_Livro(livro_id)

    def create_livro(self, titulo, isbn, data_publicacao, numero_paginas, autor_id, listaCategorias):
        return self.livroDao.add_Livro(titulo, isbn, data_publicacao, numero_paginas, autor_id, listaCategorias)

    def update_livro(self, livro_id, titulo, isbn, data_publicacao, numero_paginas, autor_id, listaCategorias):
        return self.livroDao.att_Livro(livro_id, titulo, isbn, data_publicacao, numero_paginas, autor_id, listaCategorias)

    def delete_livro(self, livro_id):
        return self.livroDao.del_Livro(livro_id)
    
    def livro_to_json(self, livro):
        return LivroDAO.livro_to_json(livro)

    def livros_to_json(self, livros):
        return LivroDAO.livros_to_json(livros)