from dao import CategoriaDAO
#Funções: Pegar todos as categorias, Pegar categoria pelo id, criar uma nova categoria, upar/atualizar uma categoria, deletar uma categoria
class CategoriaRepository:
    def __init__(self) -> None:
        self.categoriaDao = CategoriaDAO()

    def get_all_categorias(self):
        return self.categoriaDao.get_all_Categoria()

    def get_categoria_by_id(self, categoria_id):
        return self.categoriaDao.get_Categoria(categoria_id)

    def create_categoria(self, nome):
        return self.categoriaDao.add_Categoria(nome)

    def update_categoria(self, categoria_id, nome):
        return self.categoriaDao.att_Categoria(categoria_id, nome)

    def delete_categoria(self, categoria_id):
        return self.categoriaDao.del_Categoria(categoria_id)
    
    def categoria_to_json(self, categoria):
        return CategoriaDAO.categoria_to_json(categoria)

    def categorias_to_json(self, categorias):
        return CategoriaDAO.categorias_to_json(categorias)