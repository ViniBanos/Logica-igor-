from dao import AutorDAO
#Funções: Pegar todos os autores, Pegar autor pelo id, criar um novo autor, upar/atualizar um autor, deletar um autor
class AutorRepository:
    def __init__(self) -> None:
        self.autorDao = AutorDAO()

    def get_all_autores(self):
        return self.autorDao.get_all_Autor()

    def get_autor_by_id(self, autor_id):
        return self.autorDao.get_Autor(autor_id)

    def create_autor(self, nome, data_nascimento, nacionalidade):
        return self.autorDao.add_Autor( nome, data_nascimento, nacionalidade)

    def update_autor(self, autor_id, nome, data_nascimento, nacionalidade):
        return self.autorDao.att_Autor(autor_id, nome, data_nascimento, nacionalidade)

    def delete_autor(self, autor_id):
        return self.autorDao.del_Autor(autor_id)
    
    def autor_to_json(self, autor):
        return AutorDAO.autor_to_json(autor)

    def autores_to_json(self, autores):
        return AutorDAO.autores_to_json(autores)