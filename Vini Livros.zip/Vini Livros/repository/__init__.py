from .LivrosRepository import *
from .AutorRepository import *
from .CategoriaRepository import *
from .LivroCategoriaRepository import *