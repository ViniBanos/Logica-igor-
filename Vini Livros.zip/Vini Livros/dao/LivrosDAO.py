from models import Livro,Categoria, db
#Atributos: id,titulo,isbn,data_publicacao,numero_paginas,autor_id,categoria_id
class LivroDAO:
    @staticmethod
    def get_Livro(id):
        return Livro.query.get(id)

    @staticmethod
    def get_all_Livros():
        return Livro.query.all()

    @staticmethod
    def add_Livro(titulo, isbn, data_publicacao, numero_paginas, autor_id,listaCategorias):
        livro = Livro(titulo=titulo, isbn=isbn, data_publicacao=data_publicacao, numero_paginas=numero_paginas,autor_id=autor_id)
        NovaListacategoria=[]
        for categoria in listaCategorias:
            NovaListacategoria.append(Categoria.query.get(categoria))

        if None not in NovaListacategoria:
            livro.categorias= NovaListacategoria.copy()
            db.session.add(livro)
            db.session.commit()
            return livro

        return None
    @staticmethod
    def add_Livro(titulo, isbn, data_publicacao, numero_paginas, autor_id, listaCategorias):
        livro = Livro(titulo=titulo, isbn=isbn, data_publicacao=data_publicacao, numero_paginas=numero_paginas, autor_id=autor_id)
        print(livro.categorias)
        NovaListacategoria = []
        for categoria_id in listaCategorias:
            categoria = Categoria.query.get(categoria_id)
            if categoria:
                NovaListacategoria.append(categoria)
        livro.categorias = NovaListacategoria 
        print(livro.categorias)
        db.session.add(livro)
        db.session.commit()
        return livro 

    @staticmethod
    def att_Livro(id, titulo, isbn, data_publicacao, numero_paginas, autor_id,listaCategorias):
        livro = Livro.query.get(id) 
        if livro:
            livro.titulo = titulo
            livro.isbn = isbn
            livro.data_publicacao = data_publicacao
            livro.numero_paginas = numero_paginas
            livro.autor_id = autor_id
            NovaListacategoria=[]
            for categoria in listaCategorias:
                NovaListacategoria.append(Categoria.query.get(categoria))
            if None not in NovaListacategoria:
                livro.categorias= NovaListacategoria.copy()    
            db.session.commit()
        return livro

    @staticmethod
    def del_Livro(id):
        livro = LivroDAO.get_Livro(id)
        if livro:
            db.session.delete(livro)
            db.session.commit()
        return livro
    @staticmethod
    def livro_to_json(livro):
        return {
            "id": livro.id,
            "titulo": livro.titulo,
            "isbn": livro.isbn,
            "data_publicacao": livro.data_publicacao.isoformat() if livro.data_publicacao else None,
            "numero_paginas": livro.numero_paginas,
            "autor_id": livro.autor_id,
            "categorias": [categoria.id for categoria in livro.categorias]
        }
    @staticmethod
    def livros_to_json(livros):
        return [LivroDAO.livro_to_json(livro) for livro in livros]