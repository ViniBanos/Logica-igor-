from .AutorDAO import *
from .CategoriaDAO import *
from .LivrosDAO import *
from .LivroCategoriaDAO import *
from flask import jsonify
def buscar_livros(titulo,autor,categoria,isbn,repository):
    query = Livro.query
    if titulo:
        query = query.filter(Livro.titulo.ilike(f'%{titulo}%'))
    if autor:
        query = query.join(Autor).filter(Autor.nome.ilike(f'%{autor}%'))
    if categoria:
        query = query.join(Livro.categorias).filter(Categoria.nome.ilike(f'%{categoria}%'))
    if isbn:
        query = query.filter(Livro.isbn == isbn)

    livros = query.all()
    return jsonify(repository.livros_to_json(livros))

def buscar_livros_por_autor_ou_categoria():
    autor = "Gabriel"
    categoria = ""

    query = Livro.query
    if autor:
        query = query.join(Autor).filter(Autor.nome.ilike(f'%{autor}%'))
    if categoria:
        query = query.join(Livro.categorias).filter(Categoria.nome.ilike(f'%{categoria}%'))

    livros = query.all()
    return jsonify([livro.to_dict() for livro in livros])
