from models import Categoria, db

# Atributos: id, nome
class CategoriaDAO:
    @staticmethod
    def get_Categoria(id):
        return Categoria.query.get(id)

    @staticmethod
    def get_all_Categoria():
        return Categoria.query.all()

    @staticmethod
    def add_Categoria(nome):
        categoria = Categoria(nome=nome)
        if categoria:
            db.session.add(categoria)
            db.session.commit()
        return categoria

    @staticmethod
    def att_Categoria(id, nome):
        categoria = Categoria.query.get(id)
        if categoria:
            categoria.nome = nome
            db.session.commit()  
        return categoria

    @staticmethod
    def del_Categoria(id):
        categoria = CategoriaDAO.get_Categoria(id)
        if categoria:
            db.session.delete(categoria)
            db.session.commit()
        return categoria
    @staticmethod
    def categoria_to_json(categoria):
        return {
            "id": categoria.id,
            "nome": categoria.nome
        }
    @staticmethod
    def categorias_to_json(categorias):
        return [CategoriaDAO.categoria_to_json(categoria) for categoria in categorias]