from models import Livro, Categoria, db

class LivroCategoriaDAO:
    @staticmethod
    def get_all_livro_categoria():
        return db.session.query(Livro.categorias).all()

    @staticmethod
    def get_livro_categoria_by_livro_id(livro_id):
        livro = Livro.query.get(livro_id)
        if livro:
            return livro.categorias
        return None

    @staticmethod
    def get_livro_categoria_by_categoria_id(categoria_id):
        categoria = Categoria.query.get(categoria_id)
        if categoria:
            return categoria.livros
        return None

    @staticmethod
    def add_livro_categoria(livro_id, categoria_id):
        livro = Livro.query.get(livro_id)
        categoria = Categoria.query.get(categoria_id)

        if livro and categoria:
            livro.categorias.append(categoria)
            db.session.commit()
            return livro
        return None

    @staticmethod
    def remove_livro_categoria(livro_id, categoria_id):
        livro = Livro.query.get(livro_id)
        categoria = Categoria.query.get(categoria_id)

        if livro and categoria:
            livro.categorias.remove(categoria)
            db.session.commit()
            return livro
        return None
    @staticmethod
    def livro_categoria_to_json(livro_categoria):
        return {
            "livro_id": livro_categoria.id,
            "categoria_ids": [categoria.id for categoria in livro_categoria.categorias]
        }
    @staticmethod
    def livro_categorias_to_json(livros_categorias):
        return [LivroCategoriaDAO.livro_categoria_to_json(listacategoria) for listacategoria in livros_categorias]