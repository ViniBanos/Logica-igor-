from models import Autor, db
#Atributos: id,nome,data_nascimento,nacionalidade
class AutorDAO:
    @staticmethod
    def get_Autor(id):
        return Autor.query.get(id)

    @staticmethod
    def get_all_Autor():
        return Autor.query.all()

    @staticmethod
    def add_Autor(nome,data_nascimento,nacionalidade):
        autor = Autor(nome=nome,data_nascimento=data_nascimento,nacionalidade=nacionalidade)
        if autor:
            db.session.add(autor)
            db.session.commit()
        return autor

    @staticmethod
    def att_Autor(id, nome, data_nascimento, nacionalidade):
        autor = Autor.query.get(id)
        if autor:
 
            autor.nome = nome
            autor.data_nascimento = data_nascimento
            autor.nacionalidade = nacionalidade

            db.session.commit()  
        return autor

    @staticmethod
    def del_Autor(id):
        autor = AutorDAO.get_Autor(id)
        if autor:
            db.session.delete(autor)
            db.session.commit()
        return autor
    @staticmethod
    def autor_to_json(autor):
        return {
            "id": autor.id,
            "nome": autor.nome,
            "data_nascimento": autor.data_nascimento.isoformat() if autor.data_nascimento else None,
            "nacionalidade": autor.nacionalidade
        }
    @staticmethod
    def autores_to_json(autores):
        return [AutorDAO.autor_to_json(autor) for autor in autores]