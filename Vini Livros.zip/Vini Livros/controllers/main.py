from flask import Blueprint,jsonify,request,render_template,redirect,url_for
from repository import LivroCategoriaRepository,LivroRepository,AutorRepository,CategoriaRepository
from datetime import datetime
from dao import buscar_livros,buscar_livros_por_autor_ou_categoria
LBDs = Blueprint("LBDs",__name__) #Livros Banco de Dados


data_convertida = datetime.strptime("2008-02-09", "%Y-%m-%d").date()
autorRepository = AutorRepository()
#Funções: Pegar todos os autores, Pegar autor pelo id, criar um novo autor, upar/atualizar um autor, deletar um autor, um pra json, lista json
livroRepository = LivroRepository()
#Funções: Pegar todos os livros, Pegar livro pelo id, criar um novo livro, upar/atualizar um livro, deletar um livro, um pra json, lista json
categoriaRepository = CategoriaRepository() 
#Funções: Pegar todos as categorias, Pegar categoria pelo id, criar uma nova categoria, upar/atualizar uma categoria, deletar uma categoria,um pra json, lista json
livroCategoriaRepository = LivroCategoriaRepository()
#Funções: Pegar todos os livro_categoria, Pegar livro_categoria pelo id, criar um novo livro_categoria, upar/atualizar um livro_categoria, deletar um livro_categoria, um pra json, lista json

@LBDs.route('/', methods=['GET'])
def index():
    return "Bem vindo, \n teste os comandos /addVariavel /deleteX \n/autores /livros /categorias /LivroCategoria /consultaLivro /editX \n /buscar X=Autor ou Categoria ou Livro"
@LBDs.route("/addAutor",methods=['GET',"POST"])
def addAutor():
    nome="Guilherme"
    data_nascimento = datetime.strptime("2008-02-09", "%Y-%m-%d").date()
    nacionalidade="Brasileiro"
    autorRepository.create_autor(nome,data_nascimento,nacionalidade)
    return "Autor adicionado"

@LBDs.route("/addCategoria",methods=['GET',"POST"])
def addCategoria():
    nome="romance"
    categoriaRepository.create_categoria(nome)
    return "Categoria adicionada"    
    
@LBDs.route("/addLivro",methods=['GET',"POST"])
def addLivro():
    #Atributos: id,titulo,isbn,data_publicacao,numero_paginas,autor_id
    titulo="Romantic killer"
    isbn="123214"
    data_publicacao=datetime.strptime("2025-02-09", "%Y-%m-%d").date()
    numero_paginas=231
    autor_id=1
    listaCategorias=[1,2]
    livro=livroRepository.create_livro(titulo,isbn,data_publicacao,numero_paginas,autor_id,listaCategorias)
    if livro:
        return "Livro Adicionado"
    return "Errado"


@LBDs.route("/deleteAutor",methods=['GET',"POST"])
def deleteAutor():
    id_autor=1
    autorRepository.delete_autor(id_autor)
    return "Autor deletado"

@LBDs.route("/deleteCategoria",methods=['GET',"POST"])
def deleteCategoria():
    id_categoria=1
    categoriaRepository.delete_categoria(id_categoria)
    return "Categoria deletada"    
    
@LBDs.route("/deleteLivro",methods=['GET',"POST"])
def deleteLivro():
    id_livro=1
    livro=livroRepository.delete_livro(id_livro)
    return "Livro deletado"

@LBDs.route("/autores")
def getAutores():
    autores=autorRepository.get_all_autores()
    return jsonify (autorRepository.autores_to_json(autores))

@LBDs.route("/livros")
def getLivros():
    livros=livroRepository.get_all_livros()
    return jsonify (livroRepository.livros_to_json(livros))

@LBDs.route("/categorias")
def getCategorias():
    categorias=categoriaRepository.get_all_categorias()
    return jsonify (categoriaRepository.categorias_to_json(categorias))

@LBDs.route("/editAutor")
def editAutor():
    autorRepository.update_autor(1,"Gabriel",datetime.strptime("2008-02-09", "%Y-%m-%d").date(),"Mexicano")
    autor=autorRepository.get_autor_by_id(1)
    return jsonify(autorRepository.autor_to_json(autor))

@LBDs.route("/editCategoria")
def editCategoria():
    categoriaRepository.update_categoria(1,"Drama")
    categoria=categoriaRepository.get_categoria_by_id(1)
    return jsonify(categoriaRepository.categoria_to_json(categoria))

@LBDs.route("/editLivro")
def editLivro():
    livro=livroRepository.get_livro_by_id(1)
    livroRepository.update_livro(1,"Amoeba","1214",datetime.strptime("2078-02-09", "%Y-%m-%d").date(),2,1,["romance","Drama"])
    livro=livroRepository.get_livro_by_id(1)
    return jsonify(livroRepository.livro_to_json(livro))

@LBDs.route("/consultaLivro")
def consultaLivro():
    response=buscar_livros("Amoeba",None,None,"1214",livroRepository)
    return response

@LBDs.route("/busca")
def busca():
    return (buscar_livros_por_autor_ou_categoria())

@LBDs.route("/LivroCategoria")
def LivroCategoria():
    livroCategoriaRepository.add_livro_categoria(2,1)
    livroCategoria=livroCategoriaRepository.get_livro_categoria_by_livro_id(1)
    return "Sucesso"