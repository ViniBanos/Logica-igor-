from flask import Blueprint, render_template, request, url_for, redirect, session, flash, abort, make_response
from models.modelUsuario import Usuario, usuarios
from login_controller import pagina_simples

