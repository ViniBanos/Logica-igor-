from flask_sqlalchemy import SQLAlchmy

db = SQLAlchmy(app)