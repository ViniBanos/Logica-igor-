from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        nome = request.form['name']
        email = request.form['email']
        senha = request.form['password']
        confirm_password = request.form['confirmPassword']

        if len(nome) < 3:
            if '@' in email:
                if len(senha) >= 8:
                    if senha == confirm_password:
                        return redirect(url_for('sucesso'))
                    else: 
                        return redirect (url_for('error-conf'))
                else:
                    return redirect (url_for('error-senha'))
            else:
                return redirect (url_for('error-mail'))
        else:return redirect(url_for('error-nome'))
    else:
        return url_for('cadastro-again')
    

@app.route('/nome-erro')
def nomeErro():
    return render_template('nome-erro.html')

@app.route('/error-mail')
def mailError():
    return render_template('mail.-erro.html')

@app.route('/error-senha')
def senhaErro():
    return render_template('senha-erro.html')

@app.route('/error-conf')
def confError():
    return render_template('conf-erro')

@app.route('/sucesso')
def sucesso():
    return render_template('sucesso.html')

if __name__ == '__main__':
    app.run(debug=True)
